﻿namespace DalleTelegramBot.Common.Enums;

internal enum ImageSize
{
    Small,
    Medium,
    Large
}
