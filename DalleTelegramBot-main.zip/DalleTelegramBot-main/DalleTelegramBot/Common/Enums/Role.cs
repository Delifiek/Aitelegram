﻿namespace DalleTelegramBot.Common.Enums;

internal enum Role
{
    Admin,
    User,
    Optional
}