﻿namespace DalleTelegramBot.Common.IDependency;

internal interface ISingletonDependency
{
}
