﻿namespace DalleTelegramBot.Common.IDependency;

internal interface ITransientDependency
{
}
