﻿namespace DalleTelegramBot.Configurations
{
    internal class BotConfig
    {
        public static int RateLimitCount = 5;
        public static bool BotStatus = true;
    }
}
